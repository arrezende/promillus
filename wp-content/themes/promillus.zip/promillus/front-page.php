<?php global $data;?>
<?php get_header();?>
<!-- page-home -->
	<div class="container ">
		<section class="section spacer">
			<div class="col-4">
				<h2 class="title-destaque">A IMPORTÂNCIA DO LEITE MATERNO - LENDAS E FATOS NA AMAMENTAÇÃO</h2>
			</div>
			<div class="col-4">
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
			</div>
			<div class="col-4">
				<h2>lorem ipsum dolor simet</h2>
			</div>			
		</section>
	</div>
	<div class="container">
		<section class="section">
			<div class="col-8">
				<ul class="section">
					<li class="col-3">
						<h2><span>01.</span> Lorem</h2>
						<img src="" alt="">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					</li>
					<li class="col-3">
						<h2><span>01.</span> Lorem</h2>
						<img src="" alt="">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					</li>
					<li class="col-3">
						<h2><span>01.</span> Lorem</h2>
						<img src="" alt="">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					</li>
					<li class="col-3">
						<h2><span>01.</span> Lorem</h2>
						<img src="" alt="">
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
					</li>
				</ul>
			</div>
			<div class="col-4">
				<ul>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
					<li>lomre</li>
				</ul>
			</div>
		</section>
	</div>

<?php get_footer();?>