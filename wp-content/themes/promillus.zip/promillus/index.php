<?php get_header();?>
<!-- page-index -->
<!-- <div class="container section">
		<?php
			if ($data['post_layout'] != '') :
				echo '<div class="posts col-9">';
			elseif ($data['post_layout'] == 'one-col-left') :
				get_sidebar(); 
            	echo '<div class="posts col-9">';
            else :
            	echo '<div class="posts">';
            endif;

            get_template_part( 'loop' );
            wordpress_pagination();

            if ($data['post_layout'] == 'one-col'):
            	get_sidebar();
            endif;
            do_shortcode('[recent-posts]');

		?>
       
    </div>

<?php get_footer();?> -->