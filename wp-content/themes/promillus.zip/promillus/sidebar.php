<aside class="col-4">
<?php if ( is_active_sidebar( '1-widget-area' ) ) : ?>
<?php dynamic_sidebar( '1-widget-area' ); ?>
<?php endif; ?>
<?php if ( is_active_sidebar( '2-widget-area' ) ) : ?>
<?php dynamic_sidebar( '2-widget-area' ); ?>
<?php endif; ?>
<?php if ( is_active_sidebar( '3-widget-area' ) ) : ?>
<?php dynamic_sidebar( '3-widget-area' ); ?>
<?php endif; ?>
<?php if ( is_active_sidebar( '4-widget-area' ) ) : ?>
<?php dynamic_sidebar( '4-widget-area' ); ?>
<?php endif; ?>
</aside>