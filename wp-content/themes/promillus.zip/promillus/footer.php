	<?php global $data;?>   
    <footer>	
		<div class="copy section container">
			<?php if($data['footer_text'] != ''){ echo $data['footer_text']; } else { echo '© Copyright 2014. Alex Rezende'; } ?>
		</div>
		
	</footer>
    
<?php wp_footer(); ?>
</body>
</html>