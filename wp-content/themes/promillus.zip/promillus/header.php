<?php global $data;?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
  <head>
    <title><?php bloginfo('name');?></title>  
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="<?php echo esc_url( get_template_directory_uri() )  ?>/css/grid.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo esc_url( get_template_directory_uri() )  ?>/css/reset.css" rel="stylesheet" type="text/css" />
    <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo esc_url( get_template_directory_uri() )  ?>/css/circle.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo esc_url( get_template_directory_uri() )  ?>/css/animate.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo esc_url( get_template_directory_uri() )  ?>/css/lightbox.css" rel="stylesheet" type="text/css" />
    <link href='https://fonts.googleapis.com/css?family=Fredoka+One' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() )  ?>/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="<?php echo esc_url( get_template_directory_uri() )  ?>/js/lightbox.js"></script>
    
    <?php wp_head(); ?>
    <?php if($data['google_analytics'] != ''){ echo $data['google_analytics']; } ?>
    <style>
    <?php 
      if($data['css_text']){ echo $data['css_text'];} 
      if ($data['switch_bg'] != '0') : ?>
        body{background-image:  url("<?php echo $data['custom_bg']; ?>");}

      <?php endif;
      ?>
    </style>
    <?php if($data['js_text']){ echo '<script>'.$data['js_text'].'</script>'; } ?>
  </head> 

  <body <?php body_class( ); ?>>
  <!--- HEADER START -->
  <?php if(is_front_page()){ ?>
  <div class="section">
    <section class="col-6 no-margin">
      <?php 
        if ($data['banner_home'] == 1) :
          echo do_shortcode( '[banner_slider]' );
        endif;
      ?>
    </section>
    <section class="col-6 no-margin">
      <div class="section">
        <section class="col-6 no-margin bg blue">
          <?php dynamic_sidebar( 'header-widget-area' ); ?>
        </section>
        <section class="col-6 no-margin bg blue2">
          <?php dynamic_sidebar( 'header-widget-area2' ); ?>
        </section>
      </div>
      <div class="section"> 
        <section class="col-6 no-margin bg rosa">
          <?php dynamic_sidebar( 'header-widget-area3' ); ?>
        </section>
        <section class="col-6 no-margin bg rosa2">
          <?php dynamic_sidebar( 'header-widget-area4' ); ?>
        </section>
      </div>
    </section>
  </div>  
  <?php } ?> 
  <header id="header">
    <div class="container">
      <?php if($data['media_logo'] != ''){ ?> <div id="logo"><a href="<?php echo esc_url( home_url() ) ?>"><img src="<?php echo $data['media_logo'] ?>" width=" ?php echo $data['logo_width'] ?> " /></a></div> <?php } else{ ?>
        <div id="logo"><a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a></div> 
      <?php } ?>
      <nav id="menu">
          <?php wp_nav_menu( array( 'theme_location' => 'header-menu' ) ); ?>
      </nav>
    </div>
  </header>   
  <!-- HEADER END --> 
  