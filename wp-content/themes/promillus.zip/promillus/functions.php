<?php 
//Remove a barra do admim para usuarios logados

show_admin_bar(false);



//Ativa Thumbnails

//verifica se a função existe 

if (function_exists('add_theme_support')) {

add_theme_support( 'post-thumbnails' ); //adiciona o suporte ao Post Thumbanils 

//set_post_thumbnail_size(450, 200, true); // define um valor padrão para o thumbail 

add_image_size('banner-slider', 1046, 682, true); //cria um novo tamanho de imagem
add_image_size('mini-banner', 170, 143, true); //cria um novo tamanho de imagem  
add_image_size('portfolio_mini', 371, 180, true); //cria um novo tamanho de imagem 

} 

//menu

function header_menu() {

  register_nav_menu('header-menu',__( 'Header Menu' ));

}

add_action( 'init', 'header_menu' );



function footer_menu() {

  register_nav_menu('footer-menu',__( 'Footer Menu' ));

}
add_action( 'init', 'footer_menu' );

//Define o tamanho do resumo/excerpt

function get_the_box_excerpt(){

$excerpt = get_the_content();

$excerpt = strip_shortcodes($excerpt);

$excerpt = strip_tags($excerpt);

$the_str = substr($excerpt, 0, 98);

return $the_str;

}

// Widget Sidebar

    register_sidebar(array(

        'name' => __( 'Widget 1', 'widget' ),

        'id' => '1-widget-area',

        'description' => __( '1 area de widget', 'widget' ),

        'before_widget' => '<div id="%1$s" class="%2$s sidebar-widget">',

        'after_widget' => '</div>',

        'before_title' => '<span class="title-widget">',

        'after_title' => '</span>',

    ));



        register_sidebar(array(

        'name' => __( 'Widget 2', 'widget' ),

        'id' => '2-widget-area',

        'description' => __( '2 area de widget' , 'widget'),

        'before_widget' => '<div id="%1$s" class="%2$s sidebar-widget">',

        'after_widget' => '</div>',

        'before_title' => '<span class="title-widget">',

        'after_title' => '</span>',

    ));



        register_sidebar(array(

        'name' => __( 'Widget 3', 'widget' ),

        'id' => '3-widget-area',

        'description' => __( '3 area de widget', 'widget' ),

        'before_widget' => '<div id="%1$s" class="%2$s sidebar-widget">',

        'after_widget' => '</div>',

        'before_title' => '<span class="title-widget">',

        'after_title' => '</span>',

    ));



        register_sidebar(array(

        'name' => __( 'Widget 4', 'widget' ),

        'id' => '4-widget-area',

        'description' => __( '4 area de widget' , 'widget'),

        'before_widget' => '<div id="%1$s" class="%2$s sidebar-widget">',

        'after_widget' => '</div>',

        'before_title' => '<strong class="title">',

        'after_title' => '</strong>',

    ));


    //sidebar Header
    register_sidebar(array(

        'name' => __( 'Header sidebar', 'widget' ),

        'id' => 'header-widget-area',

        'description' => __( '1° item do header', 'widget' ),

        'before_widget' => '<div id="%1$s" class="%2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h2 class="title-widget">',

        'after_title' => '</h2>',

    ));

    register_sidebar(array(

        'name' => __( 'Header sidebar 2', 'widget' ),

        'id' => 'header-widget-area2',

        'description' => __( '2° item do header', 'widget' ),

        'before_widget' => '<div id="%1$s" class="%2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h2 class="title-widget">',

        'after_title' => '</h2>',

    ));

    register_sidebar(array(

        'name' => __( 'Header sidebar 3', 'widget' ),

        'id' => 'header-widget-area3',

        'description' => __( '3° item do header', 'widget' ),

        'before_widget' => '<div id="%1$s" class="%2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h2 class="title-widget">',

        'after_title' => '</h2>',

    ));

    register_sidebar(array(

        'name' => __( 'Header sidebar 4', 'widget' ),

        'id' => 'header-widget-area4',

        'description' => __( '4° item do header', 'widget' ),

        'before_widget' => '<div id="%1$s" class="%2$s">',

        'after_widget' => '</div>',

        'before_title' => '<h2 class="title-widget">',

        'after_title' => '</h2>',

    ));
//Paginação

function wordpress_pagination() {
            global $wp_query;
 
            $big = 999999999;
 
            echo paginate_links( array(
                  'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                  'format' => '?paged=%#%',
                  'current' => max( 1, get_query_var('paged') ),
                  'total' => $wp_query->max_num_pages,

            ) );
      }

// remove opções

//include_once ('functions/remove-admin.php');

// Admin Menu

require_once ('admin/index.php');

// shortcode grid

include_once('functions/grid.php');

include_once('functions/related_posts.php');

